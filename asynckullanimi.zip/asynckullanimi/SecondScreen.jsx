import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const SecondScreen = ({ navigation }) => {
  const [userData, setUserData] = useState(null);

  useEffect(() => {
    // Veriyi asyncStorage'den al
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const data = await AsyncStorage.getItem('user');
      if (data) {
        setUserData(JSON.parse(data));
      }
    } catch (error) {
      console.error('Veri alınamadı:', error);
    }
  };

  const removeData = async () => {
    try {
      // Veriyi asyncStorage'den sil
      await AsyncStorage.removeItem('user');
      // Veriyi sildikten sonra geri dön
      navigation.goBack();
    } catch (error) {
      console.error('Veri silinemedi:', error);
    }
  };

  return (
    <View style={styles.container}>
      {userData ? (
        <View>
          <Text style={styles.text}>Ad: {userData.firstName}</Text>
          <Text style={styles.text}>Soyad: {userData.lastName}</Text>
        </View>
      ) : (
        <Text style={styles.noDataText}>Kayıt bulunamadı</Text>
      )}
      <TouchableOpacity style={styles.button} onPress={removeData}>
        <Text style={styles.buttonText}>Sil</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.button} onPress={() => navigation.goBack()}>
        <Text style={styles.buttonText}>Geri Dön</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
  },
  text: {
    fontSize: 18,
    marginBottom: 12,
  },
  noDataText: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  button: {
    backgroundColor: 'blue',
    padding: 12,
    borderRadius: 4,
    width: '80%',
    alignItems: 'center',
    marginTop: 16,
  },
  buttonText: {
    color: 'white',
    fontWeight: 'bold',
  },
});

export default SecondScreen;
