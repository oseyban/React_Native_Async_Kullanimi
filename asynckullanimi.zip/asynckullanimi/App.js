// App.js
import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  StyleSheet,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Icon from 'react-native-vector-icons/FontAwesome';

const App = () => {
  const [name, setName] = useState('');
  const [surname, setSurname] = useState('');
  const [data, setData] = useState([]);
  const [showList, setShowList] = useState(false);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const storedData = await AsyncStorage.getItem('userData');
      if (storedData !== null) {
        setData(JSON.parse(storedData));
      }
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  const saveData = async () => {
    try {
      const newData = { name, surname };
      const updatedData = [...data, newData];
      await AsyncStorage.setItem('userData', JSON.stringify(updatedData));
      setData(updatedData);
      setName('');
      setSurname('');
    } catch (error) {
      console.error('Error saving data:', error);
    }
  };

  const removeData = async () => {
    try {
      await AsyncStorage.removeItem('userData');
      setData([]);
    } catch (error) {
      console.error('Error removing data:', error);
    }
  };

  const navigateToListPage = () => {
    setShowList(true);
  };

  const renderItem = ({ item }) => (
    <View style={styles.listItem}>
      <Text>{`${item.name} ${item.surname}`}</Text>
    </View>
  );

  if (showList) {
    return (
      <View style={styles.container}>
        <View style={styles.listContainer}>
          {data.length > 0 ? (
            <FlatList
              data={data}
              renderItem={renderItem}
              keyExtractor={(item, index) => index.toString()}
            />
          ) : (
            <Text style={styles.noDataText}>Kayıt bulunamadı.</Text>
          )}
        </View>
        <TouchableOpacity style={styles.backButton} onPress={() => setShowList(false)}>
          <Text style={{ color: 'white' }}>
            <Icon name="arrow-left" size={20} color="#ffffff" /> Geri Dön
          </Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          placeholder="Ad"
          value={name}
          onChangeText={(text) => setName(text)}
        />
        <View style={styles.line}></View>
        <TextInput
          style={styles.input}
          placeholder="Soyad"
          value={surname}
          onChangeText={(text) => setSurname(text)}
        />
        <View style={styles.line}></View>
        <TouchableOpacity style={styles.button} onPress={saveData}>
          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            <Icon name="save" size={20} color="white" />
            <Text style={{ color: 'white', marginLeft: 5 }}>Kaydet</Text>
          </View>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={removeData}>
          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            <Icon name="remove" size={20} color="white" />
            <Text style={{ color: 'white', marginLeft: 5 }}>Sil</Text>
          </View>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={navigateToListPage}>
          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            <Icon name="list" size={20} color="white" />
            <Text style={{ color: 'white', marginLeft: 5 }}>Listele</Text>
          </View>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    justifyContent: 'center',
  },
  inputContainer: {
    marginTop: 20,
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 0,
    marginBottom: 10,
    paddingHorizontal: 10,
  },
  line: {
    height: 1,
    backgroundColor: 'gray',
    marginBottom: 10,
  },
  button: {
    backgroundColor: '#4676f0',
    padding: 10,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 10,
  },
  listContainer: {
    flex: 1,
    marginTop: 20,
  },
  listItem: {
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: 'gray',
  },
  noDataText: {
    textAlign: 'center',
    marginTop: 20,
    fontSize: 16,
  },
  backButton: {
    backgroundColor: 'blue',
    padding: 10,
    borderRadius: 5,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 20,
  },
});

export default App;
